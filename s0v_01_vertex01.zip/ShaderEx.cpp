// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;

	m_pDev	= pDev;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	m_pVtx[0] = Vtx(-1,-1,  0);
	m_pVtx[1] = Vtx( 0, 1,  0);
	m_pVtx[2] = Vtx( 1,-1,  0);


	const char sShader[] =
	"vs_1_1             ; ���� ���̴� ���� 1.1									\n"
	"dcl_position    v0 ; ���� ��ġ�� �Է� �������� v0�� ����					\n"
	"mov oPos, v0       ; v0�� ����� ��ġ ���� ��� ��ġ �������Ϳ� ����		\n"
	;


	DWORD dwFlags = 0;

	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;
	INT				iLen	= strlen(sShader);

	hr = D3DXAssembleShader(
			sShader
		,	iLen
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	&pErr);


	if ( FAILED(hr) )
	{
		MessageBox( hWnd, (char*)pErr->GetBufferPointer(), "Err", 0);
		SAFE_RELEASE(pErr);
		return -1;
	}

	hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);

	SAFE_RELEASE(pShd);

	if ( FAILED(hr) )
		return -1;


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(Vtx::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	m_pDev->SetVertexShader(m_pVs);			// ���� ���̴� ���
	m_pDev->SetVertexDeclaration( m_pFVF );	// ���� ����
	
	// Rendering
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLELIST, 1, m_pVtx, sizeof(Vtx));

	m_pDev->SetVertexShader(NULL);			// ���� ���̴� ����
	m_pDev->SetVertexDeclaration(NULL);
}