// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;

	m_pDev	= pDev;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;


	m_pVtx[0] = VtxD(-50,  0,  0, D3DXCOLOR(1,0,0,1));
	m_pVtx[1] = VtxD( 50,  0,  0, D3DXCOLOR(0,1,0,1));
	m_pVtx[2] = VtxD(  0, 80,  0, D3DXCOLOR(0,0,1,1));


	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;


	hr = D3DXAssembleShaderFromFile(	"data/Shader.vsh"
									,	NULL
									,	NULL
									,	dwFlags
									,	&pShd
									,	&pErr);


	if ( FAILED(hr) )
	{
		char* sErr = (char*)pErr->GetBufferPointer();
		MessageBox( hWnd, sErr, "Err", 0);
		pErr->Release();
		return -1;
	}

	hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);

	SAFE_RELEASE(pShd);

	if ( FAILED(hr) )
		return -1;


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(VtxD::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	MATA		mtWld;			// World Matrix
	MATA		mtViw;			// View Matrix
	MATA		mtPrj;			// Projection Matrix

	D3DXMatrixIdentity(&mtWld);								// ���� ��ȯ�� ���� ������ �Ѵ�.

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);				// Device���� �� ����� �����´�.
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);			// Device���� ���� ����� �����´�.

	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
    m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );


	D3DXMATRIX	mtVP	= mtWld * mtViw * mtPrj;			// ���� ��� * �� ��� * ���� ���
	D3DXMatrixTranspose( &mtVP , &mtVP );					// ����� ��ġ�Ѵ�.


	// Render
	m_pDev->SetVertexShader(m_pVs);							//
	m_pDev->SetVertexDeclaration( m_pFVF );

	// ��� ����:                    c0,               , ����̹Ƿ� float4 �� 4��
	m_pDev->SetVertexShaderConstantF( 0, (FLOAT*)&mtVP , 4);

	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLELIST, 1, m_pVtx, sizeof(VtxD));

	m_pDev->SetVertexShader( NULL);
}