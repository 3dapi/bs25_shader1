// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;

	m_pTx	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;

	m_pDev	= pDev;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	m_pVtx[0] = VtxDUV1(-80, 60,  0,   0, 0,   D3DXCOLOR(1,1,1,1));
	m_pVtx[1] = VtxDUV1( 80, 60,  0,   1, 0,   D3DXCOLOR(1,1,1,1));
	m_pVtx[2] = VtxDUV1( 80,-60,  0,   1, 1,   D3DXCOLOR(1,1,1,1));
	m_pVtx[3] = VtxDUV1(-80,-60,  0,   0, 1,   D3DXCOLOR(1,1,1,1));


	DWORD dwFlags = 0;

	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;

	hr = D3DXAssembleShaderFromFile(	"data/Shader.vsh"
									,	NULL
									,	NULL
									,	dwFlags
									,	&pShd
									,	&pErr);


	if ( FAILED(hr) )
	{
		if(pErr)
		{
			MessageBox( hWnd, (char*)pErr->GetBufferPointer(), "Err", MB_ICONWARNING);
			SAFE_RELEASE(pErr);
		}
		else
		{
			MessageBox( hWnd, "File is Not exist", "Err", MB_ICONWARNING);
		}
		return -1;
	}

	hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);

	SAFE_RELEASE(pShd);

	if ( FAILED(hr) )
		return -1;


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(VtxDUV1::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;



	D3DXCreateTextureFromFile(m_pDev, "Texture/earth.bmp", &m_pTx);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);

	SAFE_RELEASE(	m_pTx	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	MATA		mtWld;			// World Matrix
	MATA		mtViw;			// View Matrix
	MATA		mtPrj;			// Projection Matrix

	D3DXMatrixIdentity(&mtWld);

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
    m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	// Render
	m_pDev->SetVertexShader(m_pVs);
	m_pDev->SetVertexDeclaration( m_pFVF );



	D3DXMATRIX	mtVP	= mtWld * mtViw * mtPrj;
	D3DXMatrixTranspose( &mtVP , &mtVP );
	m_pDev->SetVertexShaderConstantF( 0, (FLOAT*)&mtVP , 4);


	m_pDev->SetTexture( 0, m_pTx );
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

	m_pDev->SetVertexShader( NULL);
}