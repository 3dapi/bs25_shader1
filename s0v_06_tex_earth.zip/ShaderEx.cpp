// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;

	m_pTex	= NULL;
	m_pVtx	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;

	m_pDev	= pDev;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;



	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;
	
	hr = D3DXAssembleShaderFromFile(	"data/Shader.vsh"
									,	NULL
									,	NULL
									,	dwFlags
									,	&pShd
									,	&pErr);
	
	
	if ( FAILED(hr) )
	{
		if(pErr)
		{
			MessageBox( hWnd, (char*)pErr->GetBufferPointer(), "Err", MB_ICONWARNING);
			SAFE_RELEASE(pErr);
		}
		else
		{
			MessageBox( hWnd, "File is Not exist", "Err", MB_ICONWARNING);
		}
		return -1;
	}

	hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);

	SAFE_RELEASE(pShd);
	
	if ( FAILED(hr) )
		return -1;


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(VtxDUV1::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;



	

	D3DXCreateTextureFromFile(m_pDev, "Texture/earth.bmp", &m_pTex);



	// ���ؽ� ����
	INT	iNSphereSegments	= 128;
	m_iNvx = 2*iNSphereSegments*(iNSphereSegments+1);

	FLOAT fDeltaRingAngle = ( D3DX_PI / iNSphereSegments );
	FLOAT fDeltaSegAngle  = ( 2.0f * D3DX_PI / iNSphereSegments );

	m_pVtx = new VtxDUV1[m_iNvx];
	VtxDUV1* pVtx = m_pVtx;

	// Generate the group of rings for the sphere
	for( DWORD ring = 0; ring < iNSphereSegments; ring++ )
	{
		FLOAT r0 = 50 * sinf( (ring+0) * fDeltaRingAngle );
		FLOAT r1 = 50 * sinf( (ring+1) * fDeltaRingAngle );
		FLOAT y0 = 50 * cosf( (ring+0) * fDeltaRingAngle );
		FLOAT y1 = 50 * cosf( (ring+1) * fDeltaRingAngle );

		// Generate the group of segments for the current ring
		for( DWORD seg = 0; seg < (iNSphereSegments+1); seg++ )
		{
			FLOAT x0 =  r0 * sinf( seg * fDeltaSegAngle );
			FLOAT z0 =  r0 * cosf( seg * fDeltaSegAngle );
			FLOAT x1 =  r1 * sinf( seg * fDeltaSegAngle );
			FLOAT z1 =  r1 * cosf( seg * fDeltaSegAngle );

			// Add two vertices to the strip which makes up the sphere
			// (using the transformed normal to generate texture coords)
			pVtx->p.x = x0;
			pVtx->p.y = y0;
			pVtx->p.z = z0;
			pVtx->u = -((FLOAT)seg)/iNSphereSegments;
			pVtx->v = (ring+0)/(FLOAT)iNSphereSegments;
			pVtx++;

			pVtx->p.x = x1;
			pVtx->p.y = y1;
			pVtx->p.z = z1;
			pVtx->u = -((FLOAT)seg)/iNSphereSegments;
			pVtx->v = (ring+1)/(FLOAT)iNSphereSegments;
			pVtx++;
		}

	}

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);

	SAFE_RELEASE(	m_pTex	);

	SAFE_DELETE_ARRAY(	m_pVtx	);
}


INT CShaderEx::FrameMove()
{
	static float c=0;

	c=100.f * g_pApp->m_fTime;

	if(c>360.f)
		c -=360.f;

	D3DXMATRIX	mtY;
	D3DXMATRIX	mtZ;
	
	
	// ���� ��� ����
	D3DXMatrixIdentity(&m_mtWld);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtWld = mtY * mtZ;
	
	return 0;
}


void CShaderEx::Render()
{
	D3DXMATRIX		mtViw;			// View Matrix
	D3DXMATRIX		mtPrj;			// Projection Matrix
	D3DXCOLOR		color(1, 0.3F, 0.7F, 1);
	D3DXMATRIX		mtVP;



	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
    m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	

	mtVP	= m_mtWld * mtViw * mtPrj;
	D3DXMatrixTranspose( &mtVP , &mtVP );
	
	// Render
	m_pDev->SetVertexShader(m_pVs);
	m_pDev->SetVertexDeclaration( m_pFVF );


	m_pDev->SetVertexShaderConstantF( 0, (FLOAT*)&mtVP , 4);	// World * View Projection
	m_pDev->SetVertexShaderConstantF( 10, (FLOAT*)&color , 1);	// Color

	    
	m_pDev->SetTexture( 0, m_pTex );
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, m_iNvx - 2, m_pVtx, sizeof(VtxDUV1));

	m_pDev->SetVertexShader( NULL);
}