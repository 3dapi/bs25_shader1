// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;

	m_pMesh	= NULL;
	m_pTex	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;

	m_pDev	= pDev;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;


	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;

	hr = D3DXAssembleShaderFromFile(	"data/Shader.vsh"
									,	NULL
									,	NULL
									,	dwFlags
									,	&pShd
									,	&pErr);

	if ( FAILED(hr) )
	{
		if(pErr)
		{
			MessageBox( hWnd, (char*)pErr->GetBufferPointer(), "Err", MB_ICONWARNING);
			SAFE_RELEASE(pErr);
		}
		else
		{
			MessageBox( hWnd, "File is Not exist", "Err", MB_ICONWARNING);
		}
		return -1;
	}

	hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);

	SAFE_RELEASE(pShd);
	if ( FAILED(hr) )
		return -1;


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(VtxN::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;








	ID3DXMesh* pMesh = NULL;
	hr = D3DXCreateTeapot(m_pDev, &pMesh, NULL);
	hr = pMesh->CloneMeshFVF(D3DXMESH_SYSTEMMEM, VtxN::FVF, m_pDev, &m_pMesh );
	pMesh->Release();

	DWORD nVtx = m_pMesh->GetNumVertices();

	VtxN* pVtx = NULL;
	m_pMesh->LockVertexBuffer(0, (void**)&pVtx);

	for(DWORD n=0; n<nVtx; ++n)
	{
		pVtx[n].p *=32.f;
	}

	m_pMesh->UnlockVertexBuffer();
	hr = D3DXCreateTextureFromFile(m_pDev, "Texture/spheremap.bmp", &m_pTex);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);

	SAFE_RELEASE(	m_pMesh	);
	SAFE_RELEASE(	m_pTex	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW);
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
    m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_MIRROR);
	
	
	D3DXMATRIX		mtWld;				// World Matrix
	D3DXMATRIX		mtViw;				// View Matrix
	D3DXMATRIX		mtPrj;				// Projection Matrix

	D3DXMatrixIdentity(&mtWld);


	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);


	// Render
	m_pDev->SetVertexShader(m_pVs);
	m_pDev->SetVertexDeclaration( m_pFVF );


	D3DXMATRIX	mtT	= mtWld * mtViw * mtPrj;
	D3DXMatrixTranspose( &mtT, &mtT);
	m_pDev->SetVertexShaderConstantF(0, (FLOAT*)&mtT, 4);

	mtT	= mtViw;
	D3DXMatrixTranspose( &mtT, &mtT);
	m_pDev->SetVertexShaderConstantF(4, (FLOAT*)&mtT, 4);


	m_pDev->SetTexture(0, m_pTex);
	m_pMesh->DrawSubset(0);				// Daraw teapot

	m_pDev->SetTexture(0, NULL);

	m_pDev->SetVertexShader( NULL);

}