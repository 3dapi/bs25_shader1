// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;

typedef LPDIRECT3DVERTEXSHADER9			PDVS;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;

typedef LPDIRECT3DTEXTURE9				PDTX;

class CShaderEx
{
public:
	struct VtxN
	{
		D3DXVECTOR3	p;
		D3DXVECTOR3	n;

		VtxN()	{}
		VtxN(FLOAT X,FLOAT Y,FLOAT Z
			,FLOAT nX,FLOAT nY,FLOAT nZ):p(X,Y,Z),n(nX,nY,nZ){}
		enum	{FVF = (D3DFVF_XYZ|D3DFVF_NORMAL),};
	};

public:
	PDEV		m_pDev;				// Device

	PDVS		m_pVs;				// Vertex Shader
	PDVD		m_pFVF;				// Declarator

	
	D3DXMATRIX			m_mtWld;
	ID3DXMesh*			m_pMesh;
	LPDIRECT3DTEXTURE9	m_pTex;		// Environment Map texture

	
public:
	CShaderEx();
	virtual ~CShaderEx();
	
	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif

