// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;

	m_nVtx	= 0;
	m_nIdx	= 0;
	m_pVtx	= NULL;
	m_pIdx	= NULL;

	m_pTex	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;

	m_pDev	= pDev;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;



	LPD3DXMESH		pMdlS=NULL;
	if( FAILED( D3DXLoadMeshFromX( "xFile/Tiger.x",	D3DXMESH_SYSTEMMEM,	m_pDev, NULL, NULL, NULL, NULL, &pMdlS ) ) )
		return -1;
	
	
	LPD3DXMESH pMdlD=NULL;
	hr = pMdlS->CloneMeshFVF(D3DXMESH_SYSTEMMEM, VtxUV1::FVF, m_pDev, &pMdlD);
	pMdlS->Release();
	
	m_nVtx = pMdlD->GetNumVertices();
	m_nIdx = pMdlD->GetNumFaces();
	
	//	DWORD dFVF = pMdlD->GetFVF();
	
	m_pVtx = new VtxUV1[m_nVtx];
	m_pIdx = new VtxIdx[m_nIdx];
	
	void* pVtx= NULL;
	hr = pMdlD->LockVertexBuffer(0, &pVtx);
	
	memcpy(m_pVtx, pVtx, m_nVtx * sizeof(VtxUV1));
	
	hr = pMdlD->UnlockVertexBuffer();
	
	void* pIdx= NULL;
	hr = pMdlD->LockIndexBuffer(0, &pIdx);
	
	memcpy(m_pIdx, pIdx, m_nIdx * sizeof(VtxIdx));
	
	hr = pMdlD->UnlockIndexBuffer();
	
	pMdlD->Release();
	
	
	float fSCale=15;
	for(int i=0; i<m_nVtx; ++i)
	{
		m_pVtx[i].p *= fSCale;
	}
	
	D3DXCreateTextureFromFile(m_pDev, "Texture/dx5_logo.bmp", &m_pTex);
















	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;

	hr = D3DXAssembleShaderFromFile(	"data/Shader.vsh"
									,	NULL
									,	NULL
									,	dwFlags
									,	&pShd
									,	&pErr);


	if ( FAILED(hr) )
	{
		if(pErr)
		{
			MessageBox( hWnd, (char*)pErr->GetBufferPointer(), "Err", MB_ICONWARNING);
			SAFE_RELEASE(pErr);
		}
		else
		{
			MessageBox( hWnd, "File is Not exist", "Err", MB_ICONWARNING);
		}
		return -1;
	}

	hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);

	SAFE_RELEASE(pShd);

	if ( FAILED(hr) )
		return -1;


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(VtxUV1::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;



	D3DXCreateTextureFromFile(m_pDev, "Texture/earth.bmp", &m_pTex);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);

	SAFE_DELETE_ARRAY(	m_pVtx	);
	SAFE_DELETE_ARRAY(	m_pIdx	);
	SAFE_RELEASE(	m_pTex	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	MATA		mtWld;			// World Matrix
	MATA		mtViw;			// View Matrix
	MATA		mtPrj;			// Projection Matrix

	D3DXMatrixIdentity(&mtWld);

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW);
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
    m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	// Render
	m_pDev->SetVertexShader(m_pVs);
	m_pDev->SetVertexDeclaration( m_pFVF );


	D3DXMATRIX mtTex= D3DXMATRIX(
		0.5F,  0.0F,  0,	0,
		0.0F, -0.5F,  0,	0,
		0.0F,  0.0F,  1,	0,
		0.5F,  0.5F,  0,	1
		);

	D3DXMATRIX	mtT	= mtWld * mtViw * mtPrj;
	D3DXMatrixTranspose( &mtT, &mtT);
	m_pDev->SetVertexShaderConstantF( 0, (FLOAT*)&mtT, 4);


	D3DXMatrixTranspose( &mtT, &mtTex );
	m_pDev->SetVertexShaderConstantF( 8, (FLOAT*)&mtT, 4);


	m_pDev->SetTexture( 0, m_pTex );
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
		, 0
		, m_nVtx
		, m_nIdx
		, m_pIdx
		, D3DFMT_INDEX16
		, m_pVtx
		, sizeof(VtxUV1));

	m_pDev->SetVertexShader( NULL);
}