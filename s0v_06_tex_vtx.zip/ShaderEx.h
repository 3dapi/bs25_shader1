// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;

typedef LPDIRECT3DVERTEXSHADER9			PDVS;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;

typedef LPDIRECT3DTEXTURE9				PDTX;

class CShaderEx
{
public:
	struct VtxIdx
	{
		WORD a, b, c;

		VtxIdx() : a(0), b(1), c(2){}
		VtxIdx(WORD A, WORD B, WORD C) : a(A), b(B), c(C){}
	};

	struct VtxUV1
	{
		D3DXVECTOR3	p;
		FLOAT	u,v;

		VtxUV1(){}
		VtxUV1(	FLOAT X, FLOAT Y, FLOAT Z,
					FLOAT U, FLOAT V) : p(X,Y,Z), u(U), v(V){}

		enum { FVF = (D3DFVF_XYZ | D3DFVF_TEX1)};
	};

public:
	PDEV		m_pDev;				// Device

	PDVS		m_pVs;				// Vertex Shader
	PDVD		m_pFVF;				// Declarator

	
	INT						m_nVtx;
	INT						m_nIdx;
	VtxUV1*					m_pVtx;
	VtxIdx*					m_pIdx;
	LPDIRECT3DTEXTURE9		m_pTex;


	
public:
	CShaderEx();
	virtual ~CShaderEx();
	
	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif

