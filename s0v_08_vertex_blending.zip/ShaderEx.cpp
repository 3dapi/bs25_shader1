// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


void*	McUtil_CreateDeclarator(LPDIRECT3DDEVICE9 pDev, DWORD fvf);
void*	McUtil_BuilShader(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrAssem, int iLen);
void*	McUtil_BuilShaderFromFile(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrFile);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXMATRIX* v, INT nCnt= 1);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXCOLOR* v);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXVECTOR4* v);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , FLOAT* v);



CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;

	m_pTex	= NULL;
	m_fRad	= 0;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pVs	= (PDVS)McUtil_BuilShaderFromFile(m_pDev, "vs", "data/Shader.vsh");
	if(NULL == m_pVs)
		return -1;

	m_pFVF	= (PDVD)McUtil_CreateDeclarator(m_pDev, CShaderEx::VtxBlend::FVF);
	if(NULL == m_pFVF)
		return -1;


	
	for(int i=0; i<21; ++i)
	{
		m_pVtx[2*i + 0].p = D3DXVECTOR3( i-10.F, -6, 0)* 5;
		m_pVtx[2*i + 0].u = i/20.f;
		m_pVtx[2*i + 0].v = 1;

		m_pVtx[2*i + 1].p = D3DXVECTOR3( i-10.F,  6, 0)* 5;
		m_pVtx[2*i + 1].u = i/20.f;
		m_pVtx[2*i + 1].v = 0;


		FLOAT t = FLOAT(i) / 20.f;

		t *= D3DX_PI/2.F;
		m_pVtx[2*i + 0].g = 1.f - sinf(t);
		m_pVtx[2*i + 1].g = 1.f - sinf(t);
	}


	D3DXCreateTextureFromFile(m_pDev, "texture/dx5_logo.bmp", &m_pTex);

	return 0;
}


void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);

	SAFE_RELEASE(	m_pTex	);
}


INT CShaderEx::FrameMove()
{
	D3DXMatrixIdentity( &m_mtWld0 );
	D3DXMatrixIdentity( &m_mtWld1 );


	FLOAT fTime = g_pApp->GetElapsedTime();

	fTime *= 1.f;
	
	m_fRad += fTime;

	
	D3DXMATRIX	mtX;
	D3DXMATRIX	mtY;
	D3DXMATRIX	mtZ;

	FLOAT	fRadX = m_fRad;
	FLOAT	fRadY = m_fRad*2.f;
	FLOAT	fRadZ = m_fRad*3.f;

	D3DXMatrixRotationX(&mtX, fRadX);
	D3DXMatrixRotationY(&mtY, fRadY);
	D3DXMatrixRotationZ(&mtZ, fRadZ);

	m_mtWld1= mtZ * mtY * mtX;

	return 0;
}


void CShaderEx::Render()
{
	D3DXMATRIX	mtViw;		// View Matrix
	D3DXMATRIX	mtPrj;		// Projection Matrix
	// Get View and Projection Matrix
	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);


	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);


	m_pDev->SetSoftwareVertexProcessing(TRUE);

	m_pDev->SetVertexDeclaration( m_pFVF );
	m_pDev->SetVertexShader(m_pVs);

	McUtil_SetVshConstant(m_pDev,  4, &mtViw );
	McUtil_SetVshConstant(m_pDev,  8, &mtPrj );
	McUtil_SetVshConstant(m_pDev, 12, &m_mtWld0 );
	McUtil_SetVshConstant(m_pDev, 16, &m_mtWld1 );


	m_pDev->SetTexture(0, m_pTex);
	m_pDev->SetFVF(VtxBlend::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 40, m_pVtx, sizeof(VtxBlend));

	m_pDev->SetVertexShader(NULL);
	m_pDev->SetVertexDeclaration(NULL);



	m_pDev->SetRenderState( D3DRS_INDEXEDVERTEXBLENDENABLE, FALSE);
	m_pDev->SetSoftwareVertexProcessing(FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
}








void* McUtil_CreateDeclarator(LPDIRECT3DDEVICE9 pDev, DWORD fvf)
{
	LPDIRECT3DVERTEXDECLARATION9 pFVF = NULL;

	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(fvf, vertex_decl);
	if(FAILED(pDev->CreateVertexDeclaration( vertex_decl, &pFVF )))
		return NULL;

	return pFVF;
}


void* McUtil_BuilShader(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrAssem, int iLen)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	void*			pOut = NULL;
	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	
	hr = D3DXAssembleShader(
			sStrAssem
		,	iLen
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	NULL);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	if(0==_stricmp("vs", sShader))
	{
		IDirect3DVertexShader9*	p	= NULL;
		hr = pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	else if(0==_stricmp("ps", sShader))
	{
		IDirect3DPixelShader9*	p	= NULL;
		hr = pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return pOut;
}



void* McUtil_BuilShaderFromFile(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrFile)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	void*			pOut = NULL;
	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	
	hr = D3DXAssembleShaderFromFile(
			sStrFile
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	&pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "%s File is not Exist.", sStrFile);
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	if(0==_stricmp("vs", sShader))
	{
		IDirect3DVertexShader9*	p	= NULL;
		hr = pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	else if(0==_stricmp("ps", sShader))
	{
		IDirect3DPixelShader9*	p	= NULL;
		hr = pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return pOut;
}


void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXMATRIX* v, INT nCnt)
{
	for(int i=0; i<nCnt; ++i)
	{
		D3DXMATRIX	t;
		D3DXMatrixTranspose(&t, &v[i] );
		pDev->SetVertexShaderConstantF( uReg + i*4, (FLOAT*)&t, 4);
	}
}

void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, D3DXCOLOR* v)	{	pDev->SetVertexShaderConstantF(Reg , (FLOAT*)v, 1);	}
void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, D3DXVECTOR4* v){	pDev->SetVertexShaderConstantF(Reg , (FLOAT*)v, 1);	}
void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, FLOAT* v)		{	pDev->SetVertexShaderConstantF(Reg , v, 1);			}

