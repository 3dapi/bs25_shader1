// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;

typedef LPDIRECT3DVERTEXSHADER9			PDVS;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;

typedef LPDIRECT3DTEXTURE9				PDTX;

class CShaderEx
{
public:
	struct VtxBlend
	{
		D3DXVECTOR3	p;

		FLOAT		g[3];      // ����(Weight)
		BYTE		m[4];	   // ����� �ε���

		DWORD		d;			// Diffuse

		FLOAT		u,v;		// UV
		VtxBlend() : p(0,0,0), u(0), v(0), d(0xFFFFFFFF)
		{
			g[0]=g[1]=g[2]=0;
			m[0]=m[1]=m[2]=m[3]=0;
		}

		enum {	FVF = (D3DFVF_XYZB4 | D3DFVF_LASTBETA_UBYTE4 | D3DFVF_DIFFUSE | D3DFVF_TEX1),	};
	};


public:
	PDEV		m_pDev;				// Device

	PDVS		m_pVs;				// Vertex Shader
	PDVD		m_pFVF;				// Declarator


	VtxBlend	m_pVtx[42];
	PDTX		m_pTex;
	FLOAT		m_fRad;

	D3DXMATRIX	m_mtWld[40];		// World Matrix


public:
	CShaderEx();
	virtual ~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif

