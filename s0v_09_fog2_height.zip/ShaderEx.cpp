// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


void*	McUtil_CreateDeclarator(LPDIRECT3DDEVICE9 pDev, DWORD fvf);
void*	McUtil_BuilShader(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrAssem, int iLen);
void*	McUtil_BuilShaderFromFile(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrFile);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXMATRIX* v, INT nCnt= 1);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXCOLOR* v);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXVECTOR4* v);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , FLOAT* v);


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pVs	= (PDVS)McUtil_BuilShaderFromFile(m_pDev, "vs", "data/Shader.vsh");
	if(NULL == m_pVs)
		return -1;

	m_pFVF	= (PDVD)McUtil_CreateDeclarator(m_pDev, CShaderEx::VtxDUV1::FVF);
	if(NULL == m_pFVF)
		return -1;


	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	D3DXMATRIX		mtViw;			// View Matrix
	D3DXMATRIX		mtPrj;			// Projection Matrix

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);


	D3DXMATRIX	mtWV	= mtViw;
	D3DXMATRIX	mtWVP	= mtViw * mtPrj;

	FLOAT	FogF[4];

	static float fBgn	= 0.f;
	static float fEnd	= 400.f;

	static DWORD dBgn = timeGetTime();
	DWORD dEnd = timeGetTime();
	static FLOAT fD=10.f;

	if(dEnd-dBgn >60)
	{
		dBgn = dEnd;
		
		fEnd +=fD;

		if(fEnd>900)
		{
			fEnd =900;
			fD =-fD;
		}

		if(fEnd<300)
		{
			fEnd = 300;
			fD =-fD;
		}
	}

	FogF[0]	= fBgn;					// start
	FogF[1]	= fEnd;					// end
	FogF[2]	= fEnd/(fEnd - fBgn);	// FogF delta
	FogF[3]	= 1.F/(fEnd - fBgn);	// delta reciprocal

	D3DXCOLOR FogC(1.f,1.f, 1.f, 1.f);

	

	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
    m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	m_pDev->SetRenderState(D3DRS_FOGENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_FOGCOLOR, FogC);
	m_pDev->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_NONE);	// �̰� �ʿ�...

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);



	// Render
	m_pDev->SetVertexShader(m_pVs);
	m_pDev->SetVertexDeclaration( m_pFVF );

	
	McUtil_SetVshConstant(m_pDev,  0, &mtWVP);
	McUtil_SetVshConstant(m_pDev,  4, &mtWV);
	McUtil_SetVshConstant(m_pDev, 12, FogF);


	g_pApp->m_pField->Render();

	m_pDev->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pDev->SetVertexShader( NULL);
	m_pDev->SetVertexDeclaration( NULL );
}




void* McUtil_CreateDeclarator(LPDIRECT3DDEVICE9 pDev, DWORD fvf)
{
	LPDIRECT3DVERTEXDECLARATION9 pFVF = NULL;

	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(fvf, vertex_decl);
	if(FAILED(pDev->CreateVertexDeclaration( vertex_decl, &pFVF )))
		return NULL;

	return pFVF;
}


void* McUtil_BuilShader(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrAssem, int iLen)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	void*			pOut = NULL;
	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	
	hr = D3DXAssembleShader(
			sStrAssem
		,	iLen
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	NULL);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	if(0==_stricmp("vs", sShader))
	{
		IDirect3DVertexShader9*	p	= NULL;
		hr = pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	else if(0==_stricmp("ps", sShader))
	{
		IDirect3DPixelShader9*	p	= NULL;
		hr = pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return pOut;
}



void* McUtil_BuilShaderFromFile(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrFile)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	void*			pOut = NULL;
	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	
	hr = D3DXAssembleShaderFromFile(
			sStrFile
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	&pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "%s File is not Exist.", sStrFile);
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	if(0==_stricmp("vs", sShader))
	{
		IDirect3DVertexShader9*	p	= NULL;
		hr = pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	else if(0==_stricmp("ps", sShader))
	{
		IDirect3DPixelShader9*	p	= NULL;
		hr = pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return pOut;
}


void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXMATRIX* v, INT nCnt)
{
	for(int i=0; i<nCnt; ++i)
	{
		D3DXMATRIX	t;
		D3DXMatrixTranspose(&t, &v[i] );
		pDev->SetVertexShaderConstantF( uReg + i*4, (FLOAT*)&t, 4);
	}
}

void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, D3DXCOLOR* v)	{	pDev->SetVertexShaderConstantF(Reg , (FLOAT*)v, 1);	}
void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, D3DXVECTOR4* v){	pDev->SetVertexShaderConstantF(Reg , (FLOAT*)v, 1);	}
void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, FLOAT* v)		{	pDev->SetVertexShaderConstantF(Reg , v, 1);			}
