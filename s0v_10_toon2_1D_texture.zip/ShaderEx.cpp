// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


void*	McUtil_CreateDeclarator(LPDIRECT3DDEVICE9 pDev, DWORD fvf);
void*	McUtil_BuilShader(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrAssem, int iLen);
void*	McUtil_BuilShaderFromFile(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrFile);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXMATRIX* v, INT nCnt= 1);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXCOLOR* v);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXVECTOR4* v);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , FLOAT* v);


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;

	m_pVtx	= NULL;
	m_pTex	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pVs	= (PDVS)McUtil_BuilShaderFromFile(m_pDev, "vs", "data/Shader.vsh");
	if(NULL == m_pVs)
		return -1;

	m_pFVF	= (PDVD)McUtil_CreateDeclarator(m_pDev, CShaderEx::VtxN::FVF);
	if(NULL == m_pFVF)
		return -1;




	// ���ؽ� ����
	INT	iNSphereSegments	= 128;
	m_iNvx = 2*iNSphereSegments*(iNSphereSegments+1);

	FLOAT fDeltaRingAngle = ( D3DX_PI / iNSphereSegments );
	FLOAT fDeltaSegAngle  = ( 2.0f * D3DX_PI / iNSphereSegments );

	m_pVtx = new VtxN[m_iNvx];
	VtxN* pV = m_pVtx;

	// Generate the group of rings for the sphere
	for(INT ring = 0; ring < iNSphereSegments; ring++ )
	{
		FLOAT r0 = 50 * sinf( (ring+0) * fDeltaRingAngle );
		FLOAT r1 = 50 * sinf( (ring+1) * fDeltaRingAngle );
		FLOAT y0 = 50 * cosf( (ring+0) * fDeltaRingAngle );
		FLOAT y1 = 50 * cosf( (ring+1) * fDeltaRingAngle );
		
		// Generate the group of segments for the current ring
		for(INT seg = 0; seg < (iNSphereSegments+1); seg++ )
		{
			FLOAT x0 =  r0 * sinf( seg * fDeltaSegAngle );
			FLOAT z0 =  r0 * cosf( seg * fDeltaSegAngle );
			FLOAT x1 =  r1 * sinf( seg * fDeltaSegAngle );
			FLOAT z1 =  r1 * cosf( seg * fDeltaSegAngle );
			
			// Add two vertices to the strip which makes up the sphere
			// (using the transformed normal to generate texture coords)
			pV->p.x = x0;
			pV->p.y = y0;
			pV->p.z = z0;
			pV->n = pV->p;
			D3DXVec3Normalize(&pV->n, &pV->n);
			pV++;
			
			pV->p.x = x1;
			pV->p.y = y1;
			pV->p.z = z1;
			pV->n = pV->p;
			D3DXVec3Normalize(&pV->n, &pV->n);
			pV++;
		}
	}


	
	// �� ���̴��� �ؽ�ó ����
	hr = D3DXCreateTexture(m_pDev , 512, 1 , 0, 0 , D3DFMT_X8R8G8B8, D3DPOOL_MANAGED , &m_pTex );
	if ( FAILED(hr) )
		return hr;
	
	D3DLOCKED_RECT	pRect;
	m_pTex->LockRect(0, &pRect, NULL, 0);

	DWORD*	pColor	= (DWORD*)pRect.pBits;

	for(INT i = 0 ; i < 512; ++i)
	{
		FLOAT	c = 0;

		if(i<10)		c = 0;
		else if(i<100)	c= 0.2f;
		else if(i<200)	c= 0.4f;
		else if(i<300)	c= 0.6f;
		else if(i<400)	c= 0.8f;
		else			c= 1.0;

		pColor[i]	= D3DXCOLOR(c,c,c,1);
	}

	m_pTex->UnlockRect(0);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);

	SAFE_RELEASE(	m_pTex	);

	SAFE_DELETE_ARRAY(	m_pVtx	);
}


INT CShaderEx::FrameMove()
{
	float c = float( GetTickCount()) * 0.05f;

	D3DXMATRIX	mtY;
	D3DXMATRIX	mtZ;
	
	// ���� ��� ����
	D3DXMatrixIdentity(&m_mtWld);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtWld = mtY * mtZ;
	
	return 0;
}


void CShaderEx::Render()
{
	D3DXMATRIX	mtViw;			// View Matrix
	D3DXMATRIX	mtPrj;			// Projection Matrix

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);


	D3DXVECTOR4	vcLgt	= D3DXVECTOR4(-1.0f,-1.0f,1.0f, 0.F);
	D3DXCOLOR	dDiff	= D3DXCOLOR(0,1.f,1,1);
	D3DXVec4Normalize( &vcLgt , &vcLgt );
	D3DXVec3TransformNormal( (D3DXVECTOR3*)&vcLgt , (D3DXVECTOR3*)&vcLgt , &mtViw );


	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE , FALSE );

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);

	m_pDev->SetSamplerState( 0 , D3DSAMP_ADDRESSV,	D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState( 0 , D3DSAMP_ADDRESSV,	D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState( 0 , D3DSAMP_ADDRESSW,	D3DTADDRESS_CLAMP);

	m_pDev->SetTextureStageState( 0 , D3DTSS_COLORARG1 , D3DTA_TEXTURE);
	m_pDev->SetTextureStageState( 0 , D3DTSS_COLORARG2 , D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState( 0 , D3DTSS_COLOROP , D3DTOP_MODULATE);

	
	m_pDev->SetVertexDeclaration(m_pFVF);
	m_pDev->SetVertexShader(m_pVs);
	

	// ��� ����
	//      c0	= World * View * Projection matrix
	//		c4	= World matrix
	//		c8	= light direction
	//		c9	= color
	
	D3DXMATRIX	mtT = m_mtWld * mtViw * mtPrj;

	McUtil_SetVshConstant(m_pDev,  0, &mtT		);
	McUtil_SetVshConstant(m_pDev,  4, &m_mtWld	);

	McUtil_SetVshConstant(m_pDev,  8, &vcLgt	);
	McUtil_SetVshConstant(m_pDev,  9, &dDiff	);	

	m_pDev->SetTexture( 0, m_pTex );
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, m_iNvx - 2, m_pVtx, sizeof(VtxN));

	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
}








void* McUtil_CreateDeclarator(LPDIRECT3DDEVICE9 pDev, DWORD fvf)
{
	LPDIRECT3DVERTEXDECLARATION9 pFVF = NULL;

	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(fvf, vertex_decl);
	if(FAILED(pDev->CreateVertexDeclaration( vertex_decl, &pFVF )))
		return NULL;

	return pFVF;
}


void* McUtil_BuilShader(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrAssem, int iLen)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	void*			pOut = NULL;
	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	
	hr = D3DXAssembleShader(
			sStrAssem
		,	iLen
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	NULL);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	if(0==_stricmp("vs", sShader))
	{
		IDirect3DVertexShader9*	p	= NULL;
		hr = pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	else if(0==_stricmp("ps", sShader))
	{
		IDirect3DPixelShader9*	p	= NULL;
		hr = pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return pOut;
}



void* McUtil_BuilShaderFromFile(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrFile)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	void*			pOut = NULL;
	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	
	hr = D3DXAssembleShaderFromFile(
			sStrFile
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	&pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "%s File is not Exist.", sStrFile);
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	if(0==_stricmp("vs", sShader))
	{
		IDirect3DVertexShader9*	p	= NULL;
		hr = pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	else if(0==_stricmp("ps", sShader))
	{
		IDirect3DPixelShader9*	p	= NULL;
		hr = pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return pOut;
}


void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXMATRIX* v, INT nCnt)
{
	for(int i=0; i<nCnt; ++i)
	{
		D3DXMATRIX	t;
		D3DXMatrixTranspose(&t, &v[i] );
		pDev->SetVertexShaderConstantF( uReg + i*4, (FLOAT*)&t, 4);
	}
}

void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, D3DXCOLOR* v)	{	pDev->SetVertexShaderConstantF(Reg , (FLOAT*)v, 1);	}
void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, D3DXVECTOR4* v){	pDev->SetVertexShaderConstantF(Reg , (FLOAT*)v, 1);	}
void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, FLOAT* v)		{	pDev->SetVertexShaderConstantF(Reg , v, 1);			}






