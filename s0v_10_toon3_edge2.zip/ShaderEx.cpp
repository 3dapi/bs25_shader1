// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


void*	McUtil_CreateDeclarator(LPDIRECT3DDEVICE9 pDev, DWORD fvf);
void*	McUtil_BuilShader(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrAssem, int iLen);
void*	McUtil_BuilShaderFromFile(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrFile);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXMATRIX* v, INT nCnt= 1);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXCOLOR* v);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXVECTOR4* v);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , FLOAT* v);


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;

	m_pVB	= NULL;
	m_pIB	= NULL;
	
	m_pMtl	= NULL;
	m_iNmtl	= 0;

	m_pTxDiff	= NULL;
	m_pTxToon	= NULL;
	m_pTxEdge	= NULL;

	m_vcPos	=D3DXVECTOR3(0, 0, 0);
}

CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pVs	= (PDVS)McUtil_BuilShaderFromFile(m_pDev, "vs", "data/Shader.vsh");
	if(NULL == m_pVs)
		return -1;

	m_pFVF	= (PDVD)McUtil_CreateDeclarator(m_pDev, CShaderEx::VtxNDUV1::FVF);
	if(NULL == m_pFVF)
		return -1;




	LPD3DXBUFFER	pD3DXMtrlBuffer;
	LPD3DXMESH		pOriginalMesh;
	LPD3DXMESH		pMs;
	
	//Load and initialize the mesh. This is a repeat of the code
	//from Chapter 10.
	if(FAILED(D3DXLoadMeshFromX("Data/tiny.x", D3DXMESH_MANAGED, m_pDev, NULL, &pD3DXMtrlBuffer,NULL, &m_iNmtl, &pOriginalMesh)))
		return FALSE;
	
	D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
	
	m_pMtl = new DMTL[m_iNmtl];
	
	for(DWORD MatCount = 0; MatCount < m_iNmtl; MatCount++)
		m_pMtl[MatCount] = d3dxMaterials[MatCount].MatD3D;
	
	SAFE_RELEASE(	pD3DXMtrlBuffer	);
	
	//This is new. If the FVF doesn't match, clone the mesh and
	//create one that does. Then, release the loaded mesh. If the 
	//FVF does match, set the member mesh and move on.
	
	pOriginalMesh->CloneMeshFVF(D3DXMESH_MANAGED, VtxNDUV1::FVF, m_pDev, &pMs);
	SAFE_RELEASE(	pOriginalMesh	);
	
	m_iNvx = pMs->GetNumVertices();
	m_iNix = pMs->GetNumFaces();

	//Get the buffers
	pMs->GetVertexBuffer(&m_pVB);
	pMs->GetIndexBuffer(&m_pIB);


	VtxNDUV1*	pVtx;
	WORD*	pIdx;
	DWORD*	pAtt;
	
	
	m_pVB->Lock(0, m_iNvx * sizeof(VtxNDUV1), (void**)&pVtx, 0);
	m_pIB->Lock(0, m_iNix * 3 * sizeof(WORD), (void**)&pIdx, D3DLOCK_READONLY);
	
	pMs->LockAttributeBuffer(D3DLOCK_READONLY, &pAtt);
	
	for (DWORD Face = 0; Face < m_iNix; Face++)
	{
		D3DXCOLOR Diffuse = (D3DXCOLOR)m_pMtl[pAtt[Face]].Diffuse;
		
		pVtx[pIdx[Face * 3 + 0]].d = 0xFFFFFFFF;
		pVtx[pIdx[Face * 3 + 1]].d = 0xFFFFFFFF;
		pVtx[pIdx[Face * 3 + 2]].d = 0xFFFFFFFF;
	}


	for (DWORD i = 0; i < m_iNvx; ++i)
		pVtx[i].p *= 0.2f;

	
	//Give back all of our buffers.
	m_pVB->Unlock();
	m_pIB->Unlock();
	pMs->UnlockAttributeBuffer();
	SAFE_RELEASE(	pMs	);


	if(FAILED(D3DXCreateTextureFromFile(m_pDev, "Texture/Tiny.bmp", &m_pTxDiff)))
		return -1;

	if(FAILED(D3DXCreateTextureFromFile(m_pDev, "Texture/toon.png", &m_pTxToon)))
		return -1;

	if(FAILED(D3DXCreateTextureFromFile(m_pDev, "Texture/ToonEdge.png", &m_pTxEdge)))
		return -1;


	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF		);
	SAFE_RELEASE(	m_pVs		);

	SAFE_RELEASE(	m_pTxDiff		);
	SAFE_RELEASE(	m_pTxToon	);
	SAFE_RELEASE(	m_pTxEdge	);

	SAFE_RELEASE(	m_pVB		);
	SAFE_RELEASE(	m_pIB		);
	
	SAFE_DELETE_ARRAY(	m_pMtl	);
}


INT CShaderEx::FrameMove()
{
	float c = float( GetTickCount()) * 0.05f;

	// Setup World Matrix
	MATA	mtY;
	MATA	mtZ;

	D3DXMatrixRotationY(&mtY, D3DXToRadian(c));
	D3DXMatrixRotationX(&mtZ, D3DXToRadian(-90.f));

	// Rotation
	m_mtWld = mtZ * mtY;

	// Position
	m_mtWld._41 =m_vcPos.x;
	m_mtWld._42 =m_vcPos.y;
	m_mtWld._43 =m_vcPos.z;

	return 0;
}


void CShaderEx::Render()
{
	m_pDev->SetVertexDeclaration( m_pFVF );									// SetFVF
	m_pDev->SetVertexShader(m_pVs);											// Shader Code

		
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetSamplerState(2, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(2, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(2, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(2, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(2, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);


	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1,  D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2,  D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP,  D3DTOP_MODULATE);
	
	m_pDev->SetTextureStageState(1, D3DTSS_COLORARG1,  D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(1, D3DTSS_COLORARG2,  D3DTA_CURRENT);
	m_pDev->SetTextureStageState(1, D3DTSS_COLOROP,  D3DTOP_MODULATE);

	m_pDev->SetTextureStageState(2, D3DTSS_COLORARG1,  D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(2, D3DTSS_COLORARG2,  D3DTA_CURRENT);
	m_pDev->SetTextureStageState(2, D3DTSS_COLOROP,  D3DTOP_MODULATE);
	


	// Setup Vertex Shader Constant

	D3DXMATRIX	mtViw;		// View Matrix
	D3DXMATRIX	mtPrj;		// Projection Matrix

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);
	
	// ��� ����
	// Matrix = World * View * Projection
 	McUtil_SetVshConstant(m_pDev,  0, &(m_mtWld * mtViw * mtPrj) );


	// Matrix = World
	McUtil_SetVshConstant(m_pDev,  4, &m_mtWld);

	// Lighting
	D3DXVECTOR4	vcLight(-1.0, -1.0f, 1.f, 0.f);
	D3DXVec4Normalize(&vcLight, &vcLight);
	McUtil_SetVshConstant(m_pDev,  8, &vcLight);


	// Camera Z Axis
	D3DXVECTOR4	vcCamZ(mtViw._13, mtViw._23, mtViw._33, 0);
	McUtil_SetVshConstant(m_pDev, 16, &vcCamZ);


	m_pDev->SetTexture(0, m_pTxDiff);
	m_pDev->SetTexture(1, m_pTxToon);
	m_pDev->SetTexture(2, m_pTxEdge);
	
	
	m_pDev->SetStreamSource(0, m_pVB, 0, sizeof(VtxNDUV1));
	m_pDev->SetIndices(m_pIB);
	m_pDev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, m_iNvx, 0, m_iNix);

	
	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);
	m_pDev->SetTexture(2, NULL);

	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
}




void* McUtil_CreateDeclarator(LPDIRECT3DDEVICE9 pDev, DWORD fvf)
{
	LPDIRECT3DVERTEXDECLARATION9 pFVF = NULL;

	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(fvf, vertex_decl);
	if(FAILED(pDev->CreateVertexDeclaration( vertex_decl, &pFVF )))
		return NULL;

	return pFVF;
}


void* McUtil_BuilShader(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrAssem, int iLen)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	void*			pOut = NULL;
	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	
	hr = D3DXAssembleShader(
			sStrAssem
		,	iLen
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	NULL);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	if(0==_stricmp("vs", sShader))
	{
		IDirect3DVertexShader9*	p	= NULL;
		hr = pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	else if(0==_stricmp("ps", sShader))
	{
		IDirect3DPixelShader9*	p	= NULL;
		hr = pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return pOut;
}



void* McUtil_BuilShaderFromFile(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrFile)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	void*			pOut = NULL;
	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	
	hr = D3DXAssembleShaderFromFile(
			sStrFile
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	&pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "%s File is not Exist.", sStrFile);
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	if(0==_stricmp("vs", sShader))
	{
		IDirect3DVertexShader9*	p	= NULL;
		hr = pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	else if(0==_stricmp("ps", sShader))
	{
		IDirect3DPixelShader9*	p	= NULL;
		hr = pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return pOut;
}


void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXMATRIX* v, INT nCnt)
{
	for(int i=0; i<nCnt; ++i)
	{
		D3DXMATRIX	t;
		D3DXMatrixTranspose(&t, &v[i] );
		pDev->SetVertexShaderConstantF( uReg + i*4, (FLOAT*)&t, 4);
	}
}

void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, D3DXCOLOR* v)	{	pDev->SetVertexShaderConstantF(Reg , (FLOAT*)v, 1);	}
void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, D3DXVECTOR4* v){	pDev->SetVertexShaderConstantF(Reg , (FLOAT*)v, 1);	}
void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, FLOAT* v)		{	pDev->SetVertexShaderConstantF(Reg , v, 1);			}

