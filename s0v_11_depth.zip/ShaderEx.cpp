// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


void*	McUtil_CreateDeclarator(LPDIRECT3DDEVICE9 pDev, DWORD fvf);
void*	McUtil_BuilShader(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrAssem, int iLen);
void*	McUtil_BuilShaderFromFile(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrFile);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXMATRIX* v, INT nCnt= 1);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXCOLOR* v);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXVECTOR4* v);
void	McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , FLOAT* v);


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;

	m_pMshT	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pVs	= (PDVS)McUtil_BuilShaderFromFile(m_pDev, "vs", "data/Shader.vsh");
	if(NULL == m_pVs)
		return -1;

	m_pFVF	= (PDVD)McUtil_CreateDeclarator(m_pDev, CShaderEx::VtxN::FVF);
	if(NULL == m_pFVF)
		return -1;





	// ���ؽ� ����
	LPD3DXMESH	pMshO = NULL;
	
	D3DXCreateTorus(m_pDev, 25, 80, 90, 90, &pMshO, NULL);
	pMshO->CloneMeshFVF( D3DXMESH_MANAGED, VtxN::FVF, m_pDev, &m_pMshT);
	pMshO->Release();

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);

	SAFE_RELEASE(	m_pMshT	);
}


INT CShaderEx::FrameMove()
{
	float c = float( GetTickCount()) * 0.02f;

	// ���� ��� ����
	D3DXMATRIX	mtY;
	D3DXMATRIX	mtZ;	
	D3DXMatrixIdentity(&m_mtWld);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtWld = mtY * mtZ;
	
	return 0;
}


void CShaderEx::Render()
{
	D3DXMATRIX	mtViw;	// View Matrix
	D3DXMATRIX	mtPrj;	// Projection Matrix

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );

	m_pDev->SetTextureStageState( 0 , D3DTSS_COLORARG1, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState( 0 , D3DTSS_COLOROP , D3DTOP_SELECTARG1);

	m_pDev->SetVertexDeclaration(m_pFVF);
	m_pDev->SetVertexShader(m_pVs);
	

	// ��� ����
	D3DXVECTOR4 DepthRange(0, 0, 1/255.f, 0);
	McUtil_SetVshConstant(m_pDev,  0, &(m_mtWld * mtViw * mtPrj));
	McUtil_SetVshConstant(m_pDev, 26, &DepthRange);

	m_pDev->SetTexture( 0, NULL );
	m_pMshT->DrawSubset(0);

	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);

	m_pDev->SetTextureStageState( 0 , D3DTSS_COLOROP , D3DTOP_MODULATE);
}




void* McUtil_CreateDeclarator(LPDIRECT3DDEVICE9 pDev, DWORD fvf)
{
	LPDIRECT3DVERTEXDECLARATION9 pFVF = NULL;

	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(fvf, vertex_decl);
	if(FAILED(pDev->CreateVertexDeclaration( vertex_decl, &pFVF )))
		return NULL;

	return pFVF;
}


void* McUtil_BuilShader(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrAssem, int iLen)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	void*			pOut = NULL;
	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	
	hr = D3DXAssembleShader(
			sStrAssem
		,	iLen
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	NULL);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	if(0==_stricmp("vs", sShader))
	{
		IDirect3DVertexShader9*	p	= NULL;
		hr = pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	else if(0==_stricmp("ps", sShader))
	{
		IDirect3DPixelShader9*	p	= NULL;
		hr = pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return pOut;
}



void* McUtil_BuilShaderFromFile(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrFile)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	void*			pOut = NULL;
	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	
	hr = D3DXAssembleShaderFromFile(
			sStrFile
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	&pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "%s File is not Exist.", sStrFile);
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	if(0==_stricmp("vs", sShader))
	{
		IDirect3DVertexShader9*	p	= NULL;
		hr = pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	else if(0==_stricmp("ps", sShader))
	{
		IDirect3DPixelShader9*	p	= NULL;
		hr = pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return pOut;
}


void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXMATRIX* v, INT nCnt)
{
	for(int i=0; i<nCnt; ++i)
	{
		D3DXMATRIX	t;
		D3DXMatrixTranspose(&t, &v[i] );
		pDev->SetVertexShaderConstantF( uReg + i*4, (FLOAT*)&t, 4);
	}
}

void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, D3DXCOLOR* v)	{	pDev->SetVertexShaderConstantF(Reg , (FLOAT*)v, 1);	}
void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, D3DXVECTOR4* v){	pDev->SetVertexShaderConstantF(Reg , (FLOAT*)v, 1);	}
void McUtil_SetVshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, FLOAT* v)		{	pDev->SetVertexShaderConstantF(Reg , v, 1);			}
