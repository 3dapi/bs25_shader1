// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;

	m_pMshT	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	// �Լ��� ���� ��ü ����
	hr = LcDev_CreateVertexShaderFromFile(&m_pVs, m_pDev, "data/Shader.vsh");
	if(FAILED(hr))
		return -1;

	hr = LcDev_CreateVertexDeclarator((void**)&m_pFVF, m_pDev, CShaderEx::VtxN::FVF);
	if(FAILED(hr))
		return -1;



	// ���ؽ� ����
	LPD3DXMESH	pMshO = NULL;
	
	D3DXCreateTorus(m_pDev, 25, 80, 90, 90, &pMshO, NULL);
	pMshO->CloneMeshFVF( D3DXMESH_MANAGED, VtxN::FVF, m_pDev, &m_pMshT);
	pMshO->Release();

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_DELETE(	m_pVs	);

	SAFE_RELEASE(	m_pMshT	);
}


INT CShaderEx::FrameMove()
{
	float c = float( GetTickCount()) * 0.02f;

	// ���� ��� ����
	D3DXMATRIX	mtY;
	D3DXMATRIX	mtZ;	
	D3DXMatrixIdentity(&m_mtWld);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtWld = mtY * mtZ;
	
	return 0;
}


void CShaderEx::Render()
{
	D3DXMATRIX	mtViw;	// View Matrix
	D3DXMATRIX	mtPrj;	// Projection Matrix

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );

	m_pDev->SetTextureStageState( 0 , D3DTSS_COLORARG1, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState( 0 , D3DTSS_COLOROP , D3DTOP_SELECTARG1);

	
	// ���̴� ���
	m_pVs->Begin();
	m_pVs->SetFVF(m_pFVF);
	

	// ��� ����
	D3DXVECTOR4 DepthRange(0, 0, 1/255.f, 0);

	m_pVs->SetMatrix( 0, &(m_mtWld * mtViw * mtPrj));
	m_pVs->SetVector(26, &DepthRange);

	m_pDev->SetTexture( 0, NULL );
	m_pMshT->DrawSubset(0);

	// ���̴� ����
	m_pVs->End();

	m_pDev->SetTextureStageState( 0 , D3DTSS_COLOROP , D3DTOP_MODULATE);
}

