// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_


typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DVERTEXSHADER9			PDVS;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef LPDIRECT3DTEXTURE9				PDTX;


class CShaderEx
{
public:
	struct VtxN
	{
		VEC3	p;
		VEC3	n;

		VtxN()		: p(0,0,0),n(0,0,0){}
		VtxN(	FLOAT X,FLOAT Y,FLOAT Z
			,	FLOAT Nx,FLOAT Ny,FLOAT Nz)	: p(X,Y,Z),n(Nx,Ny,Nz){}

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_NORMAL)	};
	};

protected:
	PDEV		m_pDev;				// Device

	ILcShader*	m_pVs;				// Vertex Shader
	PDVD		m_pFVF;				// Declarator

	MATA		m_mtWld;			// World Matrix

	LPD3DXMESH	m_pMshT;


public:
	CShaderEx();
	virtual ~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif

