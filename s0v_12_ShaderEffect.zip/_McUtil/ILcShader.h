// Interface for the ILcShader class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILcShader_H_
#define _ILcShader_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
virtual ~CLASS_NAME(){}
#endif


interface ILcShader
{
	LC_CLASS_DESTROYER(	ILcShader	);

	virtual INT	Begin()=0;
	virtual INT	End()=0;

	virtual	INT	SetFVF(void* pFVF)=0;
	virtual INT	SetMatrix(INT nRegister, const D3DXMATRIX* v, INT Count=1)=0;
	virtual INT	SetVector(INT nRegister, const D3DXVECTOR4* v)=0;
	virtual INT	SetColor(INT nRegister, const D3DXCOLOR* v)=0;
	virtual INT	SetFloat(INT nRegister, const FLOAT* v)=0;
};


INT LcDev_CreateVertexDeclarator(void** pData, void* pDevice, DWORD FVF);

INT LcDev_CreateVertexShaderFromFile(ILcShader** pData, void* pDevice, char* sFile);
INT LcDev_CreateVertexShaderFromString(ILcShader** pData, void* pDevice, char* sString, INT iLen);

#endif

