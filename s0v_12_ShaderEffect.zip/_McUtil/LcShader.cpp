// Implementation of the CLcShader class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "ILcShader.h"


#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;
typedef D3DXQUATERNION					QUAT;
typedef D3DXCOLOR						XCLR;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DVERTEXSHADER9			PDVS;
typedef LPDIRECT3DPIXELSHADER9			PDPS;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;


class CLcShader : public ILcShader
{
protected:
	PDEV		m_pDev;
	PDVS		m_pShd;		// Vertex Shader
	INT			m_nType;	//1: File, 2:string, 3: Resource
	

public:
	CLcShader();
	virtual ~CLcShader();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();

	virtual INT		Begin();
	virtual INT		End();
	
	virtual INT		SetFVF(void* pFVF);
	virtual INT		SetMatrix(INT uReg, const D3DXMATRIX* v, INT Count=1);
	virtual INT		SetVector(INT uReg, const D3DXVECTOR4* v);
	virtual INT		SetColor(INT uReg, const D3DXCOLOR* v);
	virtual INT		SetFloat(INT nRegister, const FLOAT* v);


	void	SetSourceType(INT);

	enum	ELcShader
	{
		ELC_FILE		=1,
		ELC_STRING		=2,
		ELC_RESOURCE	=3,
	};
};


CLcShader::CLcShader()
{
	m_pShd	= NULL;
	m_nType	= 0;	//1: File, 2:string, 3: Resource
}

CLcShader::~CLcShader()
{
	Destroy();
}


INT	CLcShader::Create(void* p1, void* p2, void* p3, void* p4)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)p1;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	

	if(ELC_FILE == m_nType)
	{
		char* sFile	= (char*)p2;

		hr = D3DXAssembleShaderFromFile(
			sFile
			,	NULL
			,	NULL
			,	dwFlags
			,	&pShd
			,	&pErr);
	}
	else if(ELC_STRING == m_nType)
	{
		char* sString	= (char*)p2;
		INT iLen		= (INT)p3;

		hr = D3DXAssembleShader(
				sString
			,	iLen
			,	NULL
			,	NULL
			,	dwFlags
			,	&pShd
			,	&pErr);
	}
	else if(ELC_RESOURCE == m_nType)
	{
		DWORD dResourceId	= (DWORD)p2;

		hr = D3DXAssembleShaderFromResource(
			GetModuleHandle(NULL)
			, MAKEINTRESOURCE(dResourceId)
			,	NULL
			,	NULL
			,	dwFlags
			,	&pShd
			,	&pErr);
	}
	
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pShd);

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return 0;
}

void CLcShader::Destroy()
{
	SAFE_RELEASE(	m_pShd	);
}


INT CLcShader::Begin()
{
	return m_pDev->SetVertexShader(m_pShd);
}

INT CLcShader::End()
{
	m_pDev->SetVertexDeclaration(NULL);
	return m_pDev->SetVertexShader(NULL);
}


INT CLcShader::SetFVF(void* pFVF)
{
	return m_pDev->SetVertexDeclaration((PDVD)pFVF);
}


INT CLcShader::SetMatrix(INT uReg, const D3DXMATRIX* v, INT nCount)
{
	HRESULT hr;

	for(int i=0; i<nCount; ++i)
	{
		D3DXMATRIX	t;
		D3DXMatrixTranspose(&t, &v[i] );
		hr = m_pDev->SetVertexShaderConstantF( uReg + i*4, (FLOAT*)&t, 4);

		if(FAILED(hr))
			return -1;
	}

	return 0;
}


INT CLcShader::SetVector(INT uReg, const D3DXVECTOR4* v)
{
	return m_pDev->SetVertexShaderConstantF( uReg , (FLOAT*)v , 1);
}


INT CLcShader::SetColor(INT uReg, const D3DXCOLOR* v)
{
	return m_pDev->SetVertexShaderConstantF( uReg , (FLOAT*)v , 1);
}


INT CLcShader::SetFloat(INT uReg, const FLOAT* v)
{
	return m_pDev->SetVertexShaderConstantF( uReg , (FLOAT*)v , 1);
}






void CLcShader::SetSourceType(INT nType)
{
	m_nType	= nType;
}



INT LcDev_CreateVertexDeclarator(void** pData, void* pDevice, DWORD dFVF)
{
	PDVD	pFVF = NULL;
	PDEV	pDev = (PDEV)pDevice;

	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if(FAILED(pDev->CreateVertexDeclaration( vertex_decl, &pFVF )))
		return -1;

	*pData = pFVF;
	return 0;
}



INT LcDev_CreateVertexShaderFromFile(ILcShader** pData, void* pDevice, char* sFile)
{
	*pData	= NULL;

	CLcShader*	p = new CLcShader;
	
	p->SetSourceType(CLcShader::ELC_FILE);
	if(FAILED(p->Create(pDevice, sFile)))
	{
		delete p;
		return -1;

	}

	*pData = p;
	return 0;
}


INT LcDev_CreateVertexShaderFromString(ILcShader** pData, void* pDevice, char* sString, INT iLen)
{
	*pData	= NULL;

	CLcShader*	p = new CLcShader;
	
	//1: File, 2:string, 3: Resource
	p->SetSourceType(CLcShader::ELC_STRING);
	if(FAILED(p->Create(pDevice, sString, (void*)iLen)))
	{
		delete p;
		return -1;

	}

	*pData = p;
	return 0;
}

