// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


void*	McUtil_BuilShader(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrAssem, int iLen);
void*	McUtil_BuilShaderFromFile(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrFile);
void	McUtil_SetPshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXCOLOR* v);
void	McUtil_SetPshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , D3DXVECTOR4* v);
void	McUtil_SetPshConstant(LPDIRECT3DDEVICE9 pDev, UINT uReg , FLOAT* v);


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pPs	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pPs = (PDPS)McUtil_BuilShaderFromFile(m_pDev, "ps", "data/Shader.psh");

	if( NULL == m_pPs)
		return -1;


	m_pVtx[0] = VtxD(-0.9F,  0.9F,  0, D3DXCOLOR(1,0,0,1));
	m_pVtx[1] = VtxD( 0.9F,  0.9F,  0, D3DXCOLOR(0,1,0,1));
	m_pVtx[2] = VtxD( 0.9F, -0.9F,  0, D3DXCOLOR(0,0,1,1));
	m_pVtx[3] = VtxD(-0.9F, -0.9F,  0, D3DXCOLOR(1,0,1,1));

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pPs	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );


	m_pDev->SetPixelShader(m_pPs);		// Pixel Shader ���

	
	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxD));
	

	m_pDev->SetPixelShader( NULL);		// Pixel Shader ����
}




void* McUtil_BuilShader(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrAssem, int iLen)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	void*			pOut = NULL;
	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	
	hr = D3DXAssembleShader(
			sStrAssem
		,	iLen
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	NULL);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	if(0==_stricmp("vs", sShader))
	{
		IDirect3DVertexShader9*	p	= NULL;
		hr = pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	else if(0==_stricmp("ps", sShader))
	{
		IDirect3DPixelShader9*	p	= NULL;
		hr = pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return pOut;
}



void* McUtil_BuilShaderFromFile(LPDIRECT3DDEVICE9 pDev, char* sShader, char* sStrFile)
{
	HRESULT	hr=0;
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	void*			pOut = NULL;
	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	
	hr = D3DXAssembleShaderFromFile(
			sStrFile
		,	NULL
		,	NULL
		,	dwFlags
		,	&pShd
		,	&pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "%s File is not Exist.", sStrFile);
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}

	if(0==_stricmp("vs", sShader))
	{
		IDirect3DVertexShader9*	p	= NULL;
		hr = pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	else if(0==_stricmp("ps", sShader))
	{
		IDirect3DPixelShader9*	p	= NULL;
		hr = pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &p);
		pOut = p;
	}

	pShd->Release();
	if ( FAILED(hr) )
		return NULL;

	return pOut;
}


void McUtil_SetPshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, D3DXCOLOR* v)	{	pDev->SetPixelShaderConstantF(Reg , (FLOAT*)v, 1);	}
void McUtil_SetPshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, D3DXVECTOR4* v){	pDev->SetPixelShaderConstantF(Reg , (FLOAT*)v, 1);	}
void McUtil_SetPshConstant(LPDIRECT3DDEVICE9 pDev, UINT Reg, FLOAT* v)		{	pDev->SetPixelShaderConstantF(Reg , v, 1);			}

