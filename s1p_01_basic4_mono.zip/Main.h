#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
public:
	ID3DXFont*	m_pD3DXFont;														// D3DX font
	TCHAR		m_sMsg[512];

	CShaderEx*	m_pShader;

public:
	CMain();
	
protected:
	virtual HRESULT Init();
	virtual HRESULT Destroy();

	virtual HRESULT Restore();
	virtual HRESULT Invalidate();

	virtual HRESULT FrameMove();
	virtual HRESULT Render();

	virtual LRESULT MsgProc(HWND,UINT,WPARAM,LPARAM);
	
	void	RenderText();
};

extern CMain*	g_pApp;

#endif

