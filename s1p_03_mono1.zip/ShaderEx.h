// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_


typedef	D3DXVECTOR3				VEC3;
typedef D3DXVECTOR4				VEC4;

typedef LPDIRECT3DDEVICE9		PDEV;
typedef LPDIRECT3DPIXELSHADER9	PDPS;
typedef LPDIRECT3DTEXTURE9		PDTX;


class CShaderEx
{
public:
	struct VtxRHWUV1
	{
		VEC4	p;
		FLOAT	u, v;
		
		VtxRHWUV1()					: p(0,0,0, 1),u(0),v(0){}
		VtxRHWUV1(	FLOAT X,FLOAT Y
		,	FLOAT U, FLOAT V)		: p(X,Y,0, 1),u(U),v(V){}

		enum {FVF = (D3DFVF_XYZRHW|D3DFVF_TEX1),};
	};

public:
	PDEV		m_pDev;				// Device

	VtxRHWUV1	m_pVtx[4];			// Vertex Buffer
	PDPS		m_pPs;				// Pixel Shader
	PDTX		m_pTx;				// Texture 0

	
public:
	CShaderEx();
	virtual ~CShaderEx();
	
	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
