// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_


typedef	D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;

typedef LPDIRECT3DDEVICE9					PDEV;
typedef LPDIRECT3DPIXELSHADER9				PDPS;
typedef LPDIRECT3DTEXTURE9					PDTX;


class CShaderEx
{
public:
	struct VtxRHWDUV1
	{
		VEC4	p;
		DWORD	d;
		FLOAT	u, v;
		
		VtxRHWDUV1()				  : p(0,0,0, 1),u(0),v(0), d(0XFFFFFFFF){}
		VtxRHWDUV1(	FLOAT X,FLOAT Y
				,	FLOAT U, FLOAT V
				, DWORD D=0XFFFFFFFF) : p(X,Y,0, 1),u(U),v(V), d(D){}

		enum {FVF = (D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1),};
	};

public:
	PDEV		m_pDev;				// Device

	PDPS		m_pPs;				// Pixel Shader
	VtxRHWDUV1	m_pVtx[4];			// Vertex Buffer
	PDTX		m_pTx0;				// Texture 0
	PDTX		m_pTx1;				// Texture 1

	
public:
	CShaderEx();
	virtual ~CShaderEx();
	
	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
