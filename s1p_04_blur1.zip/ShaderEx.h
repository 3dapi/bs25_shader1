// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2							VEC2;
typedef	D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;
typedef D3DXMATRIX							MATA;

typedef LPDIRECT3DDEVICE9					PDEV;

typedef LPDIRECT3DVERTEXSHADER9				PDVS;
typedef LPDIRECT3DPIXELSHADER9				PDPS;
typedef LPDIRECT3DVERTEXDECLARATION9		PDVD;

typedef LPDIRECT3DTEXTURE9					PDTX;


class CShaderEx
{
public:
	struct VtxDUV1
	{
		VEC3	p;
		DWORD	d;
		FLOAT	u0,v0;
		FLOAT	u1,v1;
		FLOAT	u2,v2;
		FLOAT	u3,v3;
		FLOAT	u4,v4;
		
		VtxDUV1()								  : p(0,0,0), d(0xFFFFFFFF){}
		VtxDUV1(  FLOAT X, FLOAT Y, FLOAT Z
			,  FLOAT U0, FLOAT V0
			,  FLOAT U1, FLOAT V1
			,  FLOAT U2, FLOAT V2
			,  FLOAT U3, FLOAT V3
			,  FLOAT U4, FLOAT V4

			, DWORD D=0XFFFFFFFF) : p(X,Y,Z)
			, u0(U0), v0(V0)
			, u1(U1), v1(V1)
			, u2(U2), v2(V2)
			, u3(U3), v3(V3)
			, u4(U4), v4(V4)

			, d(D){}

		enum {FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX5),};
	};

public:
	PDEV		m_pDev;				// Device

	PDPS		m_pPs;				// Pixel Shader
	VtxDUV1		m_pVtx[4];			// Vertex Buffer
	PDTX		m_pTx;				// Texture

	
public:
	CShaderEx();
	virtual ~CShaderEx();
	
	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
