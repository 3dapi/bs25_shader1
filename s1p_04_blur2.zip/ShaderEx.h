// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_


typedef	D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;

typedef LPDIRECT3DDEVICE9					PDEV;
typedef LPDIRECT3DPIXELSHADER9				PDPS;
typedef LPDIRECT3DTEXTURE9					PDTX;


class CShaderEx
{
public:
	struct VtxDUV1
	{
		VEC3	p;
		DWORD	d;
		FLOAT	u,v;
		
		VtxDUV1()								  : p(0,0,0), d(0xFFFFFFFF){}
		VtxDUV1(FLOAT X,FLOAT Y,FLOAT Z,FLOAT U,FLOAT V, DWORD D=0XFFFFFFFF) : p(X,Y,Z)
			, u(U), v(V), d(D){}
		enum {FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1),};
	};

public:
	PDEV		m_pDev;				// Device

	PDPS		m_pPs;				// Pixel Shader
	VtxDUV1		m_pVtx[4];			// Vertex Buffer
	PDTX		m_pTx;				// Texture

	
public:
	CShaderEx();
	virtual ~CShaderEx();
	
	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
