// Implementation of the CLcShader class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "ILcShader.h"

#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DVERTEXSHADER9			PDVS;
typedef LPDIRECT3DPIXELSHADER9			PDPS;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;


class CLcShader : public ILcShader
{
protected:
	PDEV		m_pDev;
	PDVS		m_pVs;
	PDPS		m_pPs;

	INT			m_nType;	//0x1: File, 0x2:string, 0x3: Resource
	INT			m_nShader;	//0x00010000: Vertex Shader, 0x00020000: Pixel Shader


public:
	CLcShader();
	virtual ~CLcShader();

	virtual INT	Create(void* =0, void* =0, void* =0, void* =0);
	virtual INT	Destroy();

	virtual INT	Begin();
	virtual INT	End();

	virtual INT	SetFVF(void* pFVF);
	virtual INT	SetMatrix(INT nRegister, const D3DXMATRIX* v, INT Count=1);
	virtual INT	SetVector(INT nRegister, const D3DXVECTOR4* v);
	virtual INT	SetColor(INT nRegister, const D3DXCOLOR* v);
	virtual INT	SetFloat(INT nRegister, const FLOAT* v);

	void	SetSourceType(INT);
	void	SetShaderType(INT);

	enum	ELcShader
	{
		ELC_FILE		=0x00000001,
		ELC_STRING		=0x00000002,
		ELC_RESOURCE	=0x00000003,

		ELC_VS			=0x00010000,
		ELC_PS			=0x00020000,
	};
};



CLcShader::CLcShader()
{
	m_pVs	= NULL;
	m_pPs	= NULL;

	m_nType	= 0;	//0x1: File, 0x2:string, 0x3: Resource
	m_nShader= 0;	//0x00010000: Vertex Shader 0x00020000:Pixel Shader
}

CLcShader::~CLcShader()
{
	Destroy();
}


INT	CLcShader::Create(void* p1, void* p2, void* p3, void* p4)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)p1;

	if(0 == m_nType)
		return -1;

	if(0 == m_nShader)
		return -1;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;


	if(ELC_FILE == m_nType)
	{
		char* sFile	= (char*)p2;

		hr = D3DXAssembleShaderFromFile(
			sFile
			,	NULL
			,	NULL
			,	dwFlags
			,	&pShd
			,	&pErr);
	}
	else if(ELC_STRING == m_nType)
	{
		char* sString	= (char*)p2;
		INT iLen		= (INT)p3;

		hr = D3DXAssembleShader(
				sString
			,	iLen
			,	NULL
			,	NULL
			,	dwFlags
			,	&pShd
			,	&pErr);
	}
	else if(ELC_RESOURCE == m_nType)
	{
		DWORD dResourceId	= (DWORD)p2;

		hr = D3DXAssembleShaderFromResource(
			GetModuleHandle(NULL)
			, MAKEINTRESOURCE(dResourceId)
			,	NULL
			,	NULL
			,	dwFlags
			,	&pShd
			,	&pErr);
	}


	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return NULL;
	}


	// Vertex Shader
	if(ELC_VS == m_nShader)
		hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);

	// Pixel Shader
	else if(ELC_PS == m_nShader)
		hr = m_pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &m_pPs);

	pShd->Release();
	if ( FAILED(hr) )
		return -1;

	return 0;
}

INT CLcShader::Destroy()
{
	SAFE_RELEASE(	m_pVs	);
	SAFE_RELEASE(	m_pPs	);

	return 0;
}


INT CLcShader::Begin()
{
	if(ELC_VS == m_nShader)
		m_pDev->SetVertexShader(m_pVs);

	else if(ELC_PS == m_nShader)
		m_pDev->SetPixelShader(m_pPs);

	return 0;
}


INT CLcShader::End()
{
	if(ELC_VS == m_nShader)
		m_pDev->SetVertexShader(NULL);

	else if(ELC_PS == m_nShader)
		m_pDev->SetPixelShader(NULL);

	return 0;
}


INT CLcShader::SetFVF(void* pFVF)
{
	return m_pDev->SetVertexDeclaration((PDVD)pFVF);
}


INT CLcShader::SetMatrix(INT uReg, const D3DXMATRIX* v, INT nCount)
{
	HRESULT hr;

	for(int i=0; i<nCount; ++i)
	{
		D3DXMATRIX	t;
		D3DXMatrixTranspose(&t, &v[i] );

		if(ELC_VS == m_nShader)
			hr = m_pDev->SetVertexShaderConstantF( uReg + i*4, (FLOAT*)&t, 4);
		else if(ELC_PS == m_nShader)
			hr = m_pDev->SetPixelShaderConstantF( uReg + i*4, (FLOAT*)&t, 4);

		if(FAILED(hr))
			return -1;
	}

	return 0;
}


INT CLcShader::SetVector(INT uReg, const D3DXVECTOR4* v)
{
	if(ELC_VS == m_nShader)
		return m_pDev->SetVertexShaderConstantF( uReg , (FLOAT*)v , 1);

	return m_pDev->SetPixelShaderConstantF( uReg , (FLOAT*)v , 1);
}


INT CLcShader::SetColor(INT uReg, const D3DXCOLOR* v)
{
	if(ELC_VS == m_nShader)
		return m_pDev->SetVertexShaderConstantF( uReg , (FLOAT*)v , 1);

	return m_pDev->SetPixelShaderConstantF( uReg , (FLOAT*)v , 1);
}


INT CLcShader::SetFloat(INT uReg, const FLOAT* v)
{
	if(ELC_VS == m_nShader)
		return m_pDev->SetVertexShaderConstantF( uReg , (FLOAT*)v , 1);

	return m_pDev->SetPixelShaderConstantF( uReg , (FLOAT*)v , 1);
}


void CLcShader::SetSourceType(INT v)
{
	m_nType	= v;
}

void CLcShader::SetShaderType(INT v)
{
	m_nShader = v;
}



INT LcDev_CreateVertexDeclarator(void** pData, void* pDevice, DWORD dFVF)
{
	PDVD	pFVF = NULL;
	PDEV	pDev = (PDEV)pDevice;

	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if(FAILED(pDev->CreateVertexDeclaration( vertex_decl, &pFVF )))
		return -1;

	*pData = pFVF;
	return 0;
}


INT LcDev_CreateShaderFromFile(char* sCmd, ILcShader** pData, void* pDevice, char* sFile)
{
	*pData	= NULL;

	CLcShader*	p = new CLcShader;

	//1: File, 2:string, 3: Resource
	p->SetSourceType(CLcShader::ELC_FILE);

	if( 0 == _stricmp(sCmd, "vs"))
	{
		p->SetShaderType(CLcShader::ELC_VS);
	}
	else if( 0 == _stricmp(sCmd, "ps"))
	{
		p->SetShaderType(CLcShader::ELC_PS);
	}
	else
	{
		delete p;
		return -1;
	}


	if(FAILED(p->Create(pDevice, sFile)))
	{
		delete p;
		return -1;

	}

	*pData = p;
	return 0;
}




INT LcDev_CreateShaderFromString(char* sCmd, ILcShader** pData, void* pDevice, char* sString, INT iLen)
{
	*pData	= NULL;

	CLcShader*	p = new CLcShader;

	//1: File, 2:string, 3: Resource
	p->SetSourceType(CLcShader::ELC_STRING);

	if( 0 == _stricmp(sCmd, "vs"))
	{
		p->SetShaderType(CLcShader::ELC_VS);
	}
	else if( 0 == _stricmp(sCmd, "ps"))
	{
		p->SetShaderType(CLcShader::ELC_PS);
	}
	else
	{
		delete p;
		return -1;
	}

	if(FAILED(p->Create(pDevice, sString, (void*)iLen)))
	{
		delete p;
		return -1;

	}

	*pData = p;
	return 0;
}


