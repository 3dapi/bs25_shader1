// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;
	m_pEffect	= NULL;
	
	m_pTx	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	FLOAT	fX	= 1.f/800.f * 3.5f;
	FLOAT	fY	= 1.f/600.f * 3.5f;

	m_pVtx[0] = VtxDUV1(-1, 1,  0,  0.0F, 0, D3DXCOLOR(1,1,1,1));
	m_pVtx[1] = VtxDUV1( 1, 1,  0,  1.0F, 0, D3DXCOLOR(1,1,1,1));
	m_pVtx[2] = VtxDUV1( 1,-1,  0,  1.0F, 1, D3DXCOLOR(1,1,1,1));
	m_pVtx[3] = VtxDUV1(-1,-1,  0,  0.0F, 1, D3DXCOLOR(1,1,1,1));


	if(FAILED(LcDev_CreateShaderFromFile("ps", &m_pEffect, m_pDev, "data/Shader.psh")))
		return -1;



	D3DXCreateTextureFromFile(m_pDev, "Texture/Earth.bmp", &m_pTx);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_DELETE(	m_pEffect	);
	SAFE_RELEASE(	m_pTx		);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);


	m_pEffect->Begin();

	m_pDev->SetTexture(0, m_pTx );
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

	m_pDev->SetTexture(0, NULL);

	m_pEffect->End();
}