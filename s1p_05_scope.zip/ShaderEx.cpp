// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;
	m_pEffect	= NULL;
	
	m_pTex0	= NULL;
	m_pTex1	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;


	FLOAT	fScnW	= 800;
	FLOAT	fScnH	= 600;
	m_pVtx[0] = VtxRHWUV1(  -.5f,  -.5f,	 0.f, 0.f );
	m_pVtx[1] = VtxRHWUV1( fScnW,  -.5f,	 1.f, 0.f );
	m_pVtx[2] = VtxRHWUV1( fScnW, fScnH,	 1.f, 1.f );
	m_pVtx[3] = VtxRHWUV1(  -.5f, fScnH,	 0.f, 1.f );


	if(FAILED(LcDev_CreateShaderFromFile("ps", &m_pEffect, m_pDev, "data/Shader.psh")))
		return -1;

	D3DXCreateTextureFromFile(m_pDev, "Texture/env3.bmp", &m_pTex1);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_DELETE(	m_pEffect	);
	SAFE_RELEASE(	m_pTex1		);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);


	m_pEffect->Begin();

	D3DXCOLOR	dColor = 0xFF3fb200;
	m_pEffect->SetColor(16, &dColor);

	FLOAT	fX	= 1.f/800.f * 1.f;
	FLOAT	fY	= 1.f/600.f * 1.f;

	D3DXVECTOR4	UV0(-fX,-fY, 0, 0);
	D3DXVECTOR4	UV1( 0.,-fY, 0, 0);
	D3DXVECTOR4	UV2( fX,-fY, 0, 0);
	D3DXVECTOR4	UV3(-fX, 0., 0, 0);
	D3DXVECTOR4	UV4( 0., 0., 0, 0);
	D3DXVECTOR4	UV5( fX, 0., 0, 0);
	D3DXVECTOR4	UV6(-fX, fY, 0, 0);
	D3DXVECTOR4	UV7( 0., fY, 0, 0);
	D3DXVECTOR4	UV8( fX, fY, 0, 0);

	m_pEffect->SetVector(0, &UV0);
	m_pEffect->SetVector(1, &UV1);
	m_pEffect->SetVector(2, &UV2);
	m_pEffect->SetVector(3, &UV3);
	m_pEffect->SetVector(4, &UV4);
	m_pEffect->SetVector(5, &UV5);
	m_pEffect->SetVector(6, &UV6);
	m_pEffect->SetVector(7, &UV7);
	m_pEffect->SetVector(8, &UV8);

	// ��谡 ��� �ǵ��� Masking�� �����ؼ� ��������� ����
	// Fixel Weight
	D3DXVECTOR4	wPxl0( 1,  -1,  1, 1);
	D3DXVECTOR4	wPxl1( -1,  7, -1, 1);
	D3DXVECTOR4	wPxl2( 1,  -1,  1, 1);

	FLOAT fWeight =5.4f;
	wPxl0 *=fWeight;
	wPxl1 *=fWeight;
	wPxl2 *=fWeight;

	m_pEffect->SetVector(20, &wPxl0);
	m_pEffect->SetVector(21, &wPxl1);
	m_pEffect->SetVector(22, &wPxl2);

	m_pDev->SetTexture(0, m_pTex0);
	m_pDev->SetTexture(1, m_pTex1);
	m_pDev->SetFVF(VtxRHWUV1::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxRHWUV1));

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);

	m_pEffect->End();
}


void CShaderEx::SetSceneTexture(PDTX pTx)
{
	m_pTex0 = pTx;
}